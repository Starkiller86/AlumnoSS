<?php

namespace Metadata\Driver;

interface FileLocatorInterface
{
    /**
     * @param \ReflectionClass $class
     * @param string           $extension
     *
     * @return string|null
     */
    public function findFileForClass(\ReflectionClass $class, $extension);
}
