<?php

namespace Metadata\Tests\Fixtures\ComplexHierarchy;

class SubClassB extends BaseClass
{
    private $baz;
}