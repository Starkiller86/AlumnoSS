<?php

require __DIR__ . '/../vendors/autoload.php';

org\bovigo\vfs\vfsStreamWrapper::register();